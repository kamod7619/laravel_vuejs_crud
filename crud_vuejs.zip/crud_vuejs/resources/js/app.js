require('./bootstrap');

window.Vue = require('vue');
import Vuelidate from "vuelidate";

Vue.config.productionTip = false;
Vue.use(Vuelidate)
const axios = require('axios').default;

Vue.component('Home', require('./components/Home.vue').default)
Vue.component('Update', require('./components/Update.vue').default)
Vue.component('Create', require('./components/Create.vue').default)

const app = new Vue({
    el: '#app'
})