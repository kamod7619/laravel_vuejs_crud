<template>
	<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<h2 class="text-center p-4 pt-4">ALL DATA LARAVEL & VUEJS WITH MYSQL BY MR.KAMOD KUMAR</h2>
		</div>
		<div class="col-sm-12 text-right p-2">
			<a href="/create" class="btn btn-primary">ADD NEW USER</a>
		</div>
		<div class="col-sm-12">
			
			<table class="table text-center">
				<tr>
					<th>ID</th>
					<th>NAME</th>
					<th>EMAIL</th>
					<th>MOBILE</th>
					<th>ACTION</th>
				</tr>
				
					
				
				<tr v-for="(user,key1) in users" :key="user.id">
					<td>{{serialNumber(key1)}}</td>
					<td>{{user.name}}</td>
					<td>{{user.email}}</td>
					<td>{{user.mobile}}</td>
					<td><a v-bind:href="'/edit/'+ user.id" class="btn btn-success">EDIT</a>
						
						<a v-bind:href="'/destroy/'+ user.id" class="btn btn-danger">DELETE</a>
					</td>
					
				</tr>
				
			</table>
		</div>
	</div>
	

	</div>

</template>
<script>
const axios = require('axios');
import { required, email, minLength } from "vuelidate/lib/validators";

    export default{
        data(){
            return{
					users:{},
                    success:null,
                    errors:null,
                    
            }
        },
       
        methods:{
			loadUsers(){
				axios.get('/ShowAllUsers').then(({data})=>(this.users=data.data));
			},
			serialNumber(key) {
			  return key + 1;
			},
            
        },
         created() {
			this.loadUsers()
		  }
    }

</script>
