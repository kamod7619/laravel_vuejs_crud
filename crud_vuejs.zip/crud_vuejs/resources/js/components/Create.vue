<template>
	<div class="container">
	
	<div class="row">
	<div class="col-sm-2">
		
		</div>
		<div class="col-sm-8">
			<h2 class="text-center p-4 pt-4">CREATE NEW USER</h2>
            <div v-for="s in success" class="alert alert-success">
                <strong>{{ s }}</strong>
            </div>
            <div v-for="e in errors" class="alert alert-danger">
                <strong>{{ e }}</strong>
            </div>
			<form>
				<div class="form-group">
					<label>Name:</label>
					<input type="text" v-model="name" class="form-control">
				</div>
				<div class="form-group">
					<label>Email:</label>
					<input type="email" v-model="email" class="form-control">
				</div>
				<div class="form-group">
					<label>Mobile:</label>
					<input type="number" v-model="mobile" class="form-control">
				</div>

				<div class="form-group text-right">
					<a href="/test" class="btn btn-primary">BACK</a>
					<input type="submit" class="btn btn-primary" @click.prevent="createdata"/>
				</div>
			</form>
		</div>
		<div class="col-sm-2">
		
		</div>
	</div>

	</div>

</template>
<script>
const axios = require('axios');
import { required, email, minLength } from "vuelidate/lib/validators";

    export default{
        data(){
            return{
					users:{},
                    success:null,
                    errors:null,
                    name:'',
                    email:'',
                    mobile:''

            }
        },
        // validations:{
        //     form:{
        //         name:{required,min:minLength(10)},
        //         email:{required,email,}
        //     }
        // },
        methods:{
			
            createdata(){
                if(!this.name){
                    this.errors=['Name can not be empty!'];
                    return false;
                }
                if(!this.email){
                    this.errors=['Email can not be empty!'];
                    return false;
                }
                if(!this.mobile){
                    this.errors=['Mobile can not be empty!'];
                    return false;
                }
                axios.post('/storedata',
                {name:this.name,email:this.email,mobile:this.mobile}).then(response=>
                {
				this.success=response.data;
				window.location.href = "/test";
				}).catch(errors=>
                {this.errors=errors.data;})
				this.name='';
				this.email='';
				this.mobile='';
				
            }

        },
         mounted() {
			console.log('SUCCESS');
		  }
    }
</script>
