<template>
	<div class="container">
	
	<div class="row">
		<div class="col-sm-2">
		
		</div>
		<div class="col-sm-8">
		<h2 class="text-center p-4 pt-4">UPDATE PROFILE: {{this.user.name}}</h2>
            <div v-for="s in success" class="alert alert-success">
                <strong>{{ s }}</strong>
            </div>
            <div v-for="e in errors" class="alert alert-danger">
                <strong>{{ e }}</strong>
            </div>
			
			<form>
				
				<div class="form-group">
					<label>Name:</label>
					<input type="text" id="name" v-model="user.name" class="form-control">
				</div>
				<div class="form-group">
					<label>Email:</label>
					<input type="email" id="email" v-model="user.email" class="form-control">
				</div>
				<div class="form-group">
					<label>Mobile:</label>
					<input type="number" id="mobile" v-model="user.mobile" class="form-control">
				</div> 

				<div class="form-group">
					<a href="/test" class="btn btn-primary">BACK</a>
					<input type="submit" class="btn btn-primary" @click.prevent="updatedata"/>
				</div>
			</form>
		</div>
		<div class="col-sm-2">
		
		</div>
	</div>

	</div>

</template>
<script>
const axios = require('axios');
import { required, email, minLength } from "vuelidate/lib/validators";

    export default{
		props:['user'],
        data(){
            return{
					users:{},
                    success:null,
                    errors:null,
                    name:'',
                    email:'',
                    mobile:''

            }
			
        },
        
        methods:{
			loadUsers(){
				axios.get('/GeteditData/'+this.user.id).then(({data})=>(this.users=data.data));
			},
            updatedata(){
                if(!this.user.name){
                    this.errors=['Name can not be empty!'];
                    return false;
                }
                if(!this.user.email){
                    this.errors=['Email can not be empty!'];
                    return false;
                }
                if(!this.user.mobile){
                    this.errors=['Mobile can not be empty!'];
                    return false;
                }
                axios.post('/update/'+this.user.id,
                {name:this.user.name,email:this.user.email,mobile:this.user.mobile}).then(response=>
                {
				this.success=response.data;
				window.location.href = "/test";
				}).catch(errors=>
                {this.errors=errors.data;})
				console.log("success");
				this.loadUsers();
            }

        },
         created() {
			this.loadUsers()
		  },
		   mounted() {
            console.log(this.user,'Component mounted.')
        }
    }
</script>
