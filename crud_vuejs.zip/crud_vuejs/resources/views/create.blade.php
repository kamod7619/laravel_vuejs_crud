@extends('layouts.app')

@section('title', 'CREATE NEW USER')

@section('styles')

@endsection

@section('content')

<Create>
</Create>






@endsection

@section('scripts')

@endsection


