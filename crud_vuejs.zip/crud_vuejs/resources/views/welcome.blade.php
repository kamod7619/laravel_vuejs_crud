@extends('layouts.app')

@section('title', 'Kamod Kumar')

@section('styles')

@endsection

@section('content')

Hello Welcome To Laravel and VueJS CRUD Operation






@endsection

@section('scripts')

@endsection


