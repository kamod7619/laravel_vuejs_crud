@extends('layouts.app')

@section('title', 'Kamod Kumar')

@section('styles')

@endsection

@section('content')

<Update :user="{{$user}}">
</Update>






@endsection

@section('scripts')

@endsection


