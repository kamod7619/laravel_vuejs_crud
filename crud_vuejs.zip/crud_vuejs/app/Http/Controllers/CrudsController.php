<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent;

class CrudsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		
        return view('form');
    }

	public function ShowAllUsers()
    {
		$data=User::latest()->paginate(10);
		//$data=User::all();
        return $data;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		User::create([
			'name' => $request->name, 'email' => $request->email,'mobile'=>$request->mobile
		]);
		//DB::table('users')->insert(['name' => $request->name, 'email' => $request->email,'mobile'=>$request->mobile]);
        return response()->json(['Data Inserted Successfully.!']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(!$id) {
            return;
        }
        $user = User::find($id);
        return view('update',compact('user'));
        //return response()->json(['data' => $post]);
    }

	public function GeteditData($id)
    {
        if(!$id) {
            return;
        }
        //$user = User::find($id);
		$specialite=User::findOrFail($id);
        $user = User::where('id',$specialite)->get();
        //return view('update',compact('user'));
        //return response($user,Response::HTTP_OK);
        return json_encode($user);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
		
		$crud = User::findOrFail($id);
		$crud->name = $request->name;
		$crud->email = $request->email;
		$crud->mobile = $request->mobile;
		$crud->save();

		return response()->json(['UPDATED.!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $result=User::destroy($id);
		if($result){
			return redirect()->back()->with('msg', 'Data DELETED Successfully');
		}else{
			return response()->json(['SOMTHING WENT WRONG.!']);
		}
    }
}
