<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/test', [App\Http\Controllers\CrudsController::class,'index'])->name('test');
Route::get('/create', [App\Http\Controllers\CrudsController::class,'create'])->name('create');
Route::get('/ShowAllUsers', [App\Http\Controllers\CrudsController::class,'ShowAllUsers'])->name('ShowAllUsers');
Route::get('/edit/{id}', [App\Http\Controllers\CrudsController::class,'edit'])->name('edit');
Route::get('/GeteditData/{id}', [App\Http\Controllers\CrudsController::class,'GeteditData'])->name('GeteditData');
Route::post('/update/{id}', [App\Http\Controllers\CrudsController::class,'update'])->name('update');
Route::get('/destroy/{id}', [App\Http\Controllers\CrudsController::class,'destroy'])->name('destroy');
Route::post('/storedata', [App\Http\Controllers\CrudsController::class,'store'])->name('storedata');
//Route::resource('/test',App\Http\Controllers\CrudsController::class);
